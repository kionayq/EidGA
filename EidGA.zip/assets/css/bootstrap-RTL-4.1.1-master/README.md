# bootstrap-RTL-4.1.1


bootstrap RTL for arabic language

Call bootstrap-rtl.css after the basic Bootstrap file

bootstrap RTL للاستخدام في مواقع العربية ومواقع المتعددة اللغات

فقط قم باستدعاء ملف

bootstrap-rtl.css

بعد ملف 

bootstrap.css

