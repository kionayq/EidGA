   
<?php
header("location:Eid.html");
?>
